const mysql = require('mysql2/promise');
const pool = mysql.createPool({
host: 'localhost',
user: 'root',
password: '',
database: 'shop_db',
charset: 'utf8mb4'
});
module.exports = pool; // ต้องมีบรรทัดนี้ เพื่อส่งออก pool ไปใช้ที่อื่น