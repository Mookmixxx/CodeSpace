const express = require('express');
const multer = require('multer');
const app = express();
const db = require('./db');
const path = require('path');

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

//
// ตั้งค่า Multer
//
const storage = multer.diskStorage({
    destination: './public/images/',
    filename: (req, file, cb) => {
        cb(null, file.originalname);
    }
});
const upload = multer({ storage: storage });

//
// READ: ดึงประเภทสินค้า
//
app.get('/api/categories', async (req, res) => {
    try {
        const [rows] = await db.query("SELECT * FROM categories");
        res.json(rows);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.get('/api/products/:id', async (req, res) => {
    const [rows] = await db.query('SELECT * FROM products WHERE id = ?', [req.params.id]);
    res.json(rows[0]);
});

//
// READ: ดึงสินค้า
//
app.get('/api/products', async (req, res) => {
    try {
        const sql = `
            SELECT p.*, c.name AS category_name
            FROM products p
            LEFT JOIN categories c ON p.category_id = c.id
        `;
        const [products] = await db.query(sql);
        res.json(products);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

//
// DELETE: ลบสินค้า
//
app.delete('/api/products/:id', async (req, res) => {
    try {
        const productId = req.params.id;
        const sql = "DELETE FROM products WHERE id = ?";

        const [result] = await db.query(sql, [productId]);

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "ไม่พบสินค้า" });
        }

        res.json({ message: "ลบข้อมูลสำเร็จ" });

    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

//
// CREATE: เพิ่มสินค้า
//
app.post('/api/products', upload.single('image'), async (req, res) => {
    try {
        const { name, price, category_id } = req.body;

        const image_url = req.file
            ? `/images/${req.file.filename}`
            : '/images/no-image.png';

        const sql = `
            INSERT INTO products (name, price, image_url, category_id)
            VALUES (?, ?, ?, ?)
        `;

        await db.query(sql, [name, price, image_url, category_id]);

        res.json({ message: 'เพิ่มสินค้าเรียบร้อยแล้ว!' });

    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});



app.put('/api/products/:id', upload.single('image'), async (req, res) => {
    try {
        const { id } = req.params;
        const { name, price, category_id } = req.body; 
        let sql, params;

        if (req.file) {
            const image_url = `/images/${req.file.filename}`;
            sql = 'UPDATE products SET name=?, price=?, category_id=?, image_url=? WHERE id=?';
            params = [name, price, category_id, image_url, id];
        } else {
            sql = 'UPDATE products SET name=?, price=?, category_id=? WHERE id=?';
            params = [name, price, category_id, id];
        }

        await db.query(sql, params);
        res.json({ message: 'Update success' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

app.listen(3000, () => console.log('Server running on port 3000'));